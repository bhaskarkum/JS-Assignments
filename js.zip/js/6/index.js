function myFunction(){
    var list=["hello","world","in","a","frame"];
    console.log("********");
    for(i=0;i<listt.length;i++){
        console.log("*"+listt[i]+"*");
    }
    console.log("********");

}
myFunction();