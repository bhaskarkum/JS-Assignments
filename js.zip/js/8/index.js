var arr=[1,2,3];
var brr=["a","b","c"];
console.log(arr.concat(brr));